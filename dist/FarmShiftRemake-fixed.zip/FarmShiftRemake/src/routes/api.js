// Các endpoint /api/* kết hợp chuỗi thuật toán xử lý dữ liệu và lượng tử hoàn chỉnh (V3)
const express = require("express");
const { CROPS } = require("../config/crops");
const { clamp, round, uniform } = require("../utils/helpers");
const { debug, timer } = require("../utils/logger");
const { classifyCoordinates } = require("../utils/geoClassifier");
const { fetchNasa, fetchRainfallHistory, computeDerived, buildSatelliteSummary } = require("../services/nasa");
const {SCIENTIFIC_CROP_PROFILES} = require("../algorithms/11_crop_suitability_fuzzy_ecocrop");
const {fetchColdHistory,fetchElevation,describeTerrain,assessColdRisk} = require('../services/coldRisk');
const { scoreScenario } = require("../services/scoring");
const { generateAlerts } = require("../services/alerts");
const { runQuantum } = require("../quantum/qaoa");
const { smoothTimeSeriesSavitzkyGolay, extractPhenologyMetrics } = require("../algorithms/07_timeseries_savitzky_golay");
const { detectEnvironmentalAnomalies } = require("../algorithms/08_anomaly_detection_spi");
const { clusterSeasonalClimate } = require("../algorithms/09_unsupervised_agro_clustering");
const { deriveAHPWeightsFromPreferences, rankScenariosTOPSIS } = require("../algorithms/12_mcda_ahp_topsis");

function createApiRouter({climateProvider=fetchNasa,historyProvider=fetchRainfallHistory,coldHistoryProvider=fetchColdHistory,elevationProvider=fetchElevation,quantumOptions={}}={}) {
const router = express.Router();

// ─── POST /api/analyze ───────────────────────────────────────────────────────
router.post("/analyze", async (req, res) => {
  try {
    const body = req.body || {};
    debug("analyze body:", JSON.stringify(body));

    const lat = body.lat, lon = body.lon;
    if (!Number.isFinite(lat) || !Number.isFinite(lon) || lat < -90 || lat > 90 || lon < -180 || lon > 180) {
      return res.status(400).json({ok:false,error:'lat/lon phải là số hữu hạn trong [-90,90] và [-180,180].'});
    }
    for (const key of ['w_water','w_soil','w_profit']) {
      if (body[key] !== undefined && (!Number.isFinite(body[key]) || body[key]<0 || body[key]>1)) {
        return res.status(400).json({ok:false,error:'Trọng số phải là số trong [0,1].'});
      }
    }
    if (body.user_crops !== undefined && (!Array.isArray(body.user_crops) || body.user_crops.length!==3 || body.user_crops.some(c=>!Object.hasOwn(CROPS,c)))) {
      return res.status(400).json({ok:false,error:'user_crops phải gồm đúng 3 cây hợp lệ.'});
    }
    const preferences = deriveAHPWeightsFromPreferences([body.w_soil ?? 0.33, body.w_water ?? 0.33, body.w_profit ?? 0.34]);
    const [wSoil,wWater,wProfit] = preferences.weights;

    let userCrops = Array.isArray(body.user_crops) ? body.user_crops.slice(0, 3) : ["Rice", "Soybean", "Maize"];
    userCrops = userCrops.map((c) => (c in CROPS ? c : "Rice"));
    while (userCrops.length < 3) userCrops.push("Rice");

    // 1) Kiểm tra địa lý (Ocean, Ice Sheet, Land) bằng Geo-Classifier
    const geoCheck = classifyCoordinates(lat, lon);
    if (geoCheck.is_water) {
      return res.json({
        ok: false,
        is_water: true,
        terrain_type: "OCEAN",
        error: geoCheck.message || "Tọa độ này nằm trên đại dương/mặt nước. Vui lòng chọn khu vực đất liền!"
      });
    }
    if (geoCheck.is_ice) {
      return res.json({
        ok: false,
        is_ice: true,
        terrain_type: "ICE_SHEET",
        error: geoCheck.message || "Tọa độ này nằm trên dải băng tuyết vĩnh cửu (Greenland / Vùng cực). Không có tầng đất trồng trọt!"
      });
    }

    // 2) Lấy Dữ liệu NASA & Tiền xử lý QC (Thuật toán 01 + 03)
    let done = timer("1. NASA fetch + QC + derived");
    const rawNasa = await climateProvider(lat, lon);

    if (rawNasa._is_water) {
      return res.json({
        ok: false,
        is_water: true,
        terrain_type: "OCEAN",
        error: rawNasa.message || "Tọa độ này nằm trên đại dương/mặt nước. Vệ tinh nông nghiệp không có dữ liệu đất liền."
      });
    }
    if (rawNasa._is_ice) {
      return res.json({
        ok: false,
        is_ice: true,
        terrain_type: "ICE_SHEET",
        error: rawNasa.message || "Tọa độ này thuộc dải băng tuyết vĩnh cửu. Không có đất nông nghiệp!"
      });
    }

    if (rawNasa._unavailable || rawNasa._mock || rawNasa.recommendation_allowed === false) {
      done('(unavailable)');
      return res.status(503).json({ok:false,source_status:rawNasa.source_status || 'unavailable',
        recommendation_allowed:false,source:rawNasa._source_description || 'NASA POWER unavailable',
        error:'Không có đủ dữ liệu khí hậu có nguồn để phân tích. Vui lòng thử lại sau.',
        provenance:rawNasa._provenance || {status:'unavailable'},variables:rawNasa._raw_catalog || {},
        spi:{status:'unavailable',reason:'No validated monthly history loaded'},scenarios:null,match_pct:null});
    }
    const nasa = computeDerived(rawNasa);
    done(`(${nasa.source_status})`);

    // 3) Áp dụng lọc Savitzky-Golay (Thuật toán 07) làm mịn đường cong tán lá
    if (nasa.NDVI && nasa.NDVI.length === 12) {
      nasa.NDVI_SMOOTHED = smoothTimeSeriesSavitzkyGolay(nasa.NDVI);
      nasa._raw_catalog.NDVI_SMOOTHED = nasa.NDVI_SMOOTHED.map((value,i) => ({
        ...nasa._raw_catalog.NDVI[i],variable:'NDVI_SMOOTHED',value,
        product:'Savitzky-Golay smoothed climate NDVI proxy',dependencies:['NDVI']
      }));
      nasa._phenology = extractPhenologyMetrics(nasa.NDVI_SMOOTHED);
    }

    // 4) Nhận diện bất thường SPI và Khí hậu cực đoan (Thuật toán 08)
    const [history,coldHistory,elevation] = await Promise.all([
      Promise.resolve().then(()=>historyProvider(lat,lon)).catch(e=>({status:'unavailable',records:[],reason:e.message})),
      Promise.resolve().then(()=>coldHistoryProvider(lat,lon)).catch(e=>({status:'unavailable',records:[],reason:e.message})),
      Promise.resolve().then(()=>elevationProvider(lat,lon)).catch(e=>({status:'unavailable',value:null,reason:e.message}))
    ]);
    nasa._cold_risk=assessColdRisk(nasa,coldHistory);
    nasa._terrain=describeTerrain(nasa,elevation);
    nasa._raw_catalog.T2M_MIN_HISTORY=nasa._cold_risk.months.map(m=>({variable:'T2M_MIN_HISTORY',
      month:m.month,value:m.daily?.minimum_tmin_c ?? null,status:m.daily?.valid_days?'historical_extreme':'missing',
      source:coldHistory.source || 'NASA POWER daily T2M_MIN',product:'Minimum daily Tmin by calendar month over available history',
      unit:'°C',period:coldHistory.period || null,valid_days:m.daily?.valid_days || 0,missing_days:m.daily?.missing_days ?? null,
      limitations:'Historical reanalysis extreme; not climatology, forecast or observed plant mortality.'}));
    const envAnomalies = detectEnvironmentalAnomalies(nasa,history.status==='unavailable' ? null : history.records);

    // 5) Phân cụm mùa vụ vi khí hậu 12 tháng (Thuật toán 09)
    const seasonalRegimes = clusterSeasonalClimate(nasa, 3);

    const satellite = buildSatelliteSummary(nasa);
    const alerts = generateAlerts(nasa, envAnomalies);

    // Bổ sung các cảnh báo vật lý từ SPI / Khí hậu cực đoan nếu chưa có
    if (envAnomalies && Array.isArray(envAnomalies.alerts)) {
      envAnomalies.alerts.forEach(ea => {
        const alreadyExists = alerts.some(a => {
          const text = (typeof a === "string" ? a : (a && a.msg) || "");
          return (ea.satellite && text.includes(ea.satellite)) || (ea.msg && text.includes(ea.msg));
        });
        if (ea.level === "danger" && !alreadyExists) {
          alerts.unshift({ level: ea.level || "danger", msg: ea.msg });
        }
      });
    }

    // 6) Chấm điểm kịch bản đa tiêu chí (FAO EcoCrop & MCDA V2 - Thuật toán 11)
    done = timer("2. scoring baseline + user");
    const baselineCrops = ["Rice", "Rice", "Fallow"];
    const baseline = scoreScenario(baselineCrops, nasa, wWater, wSoil, wProfit);
    const user = scoreScenario(userCrops, nasa, wWater, wSoil, wProfit);
    done();

    // 7) Tối ưu hóa Luân canh Cổ điển & Lượng tử QAOA (Thuật toán 13)
    done = timer("3. quantum QAOA");
    const q = runQuantum(nasa, wWater, wSoil, wProfit, quantumOptions);
    const quantum = scoreScenario(q.crops, nasa, wWater, wSoil, wProfit);
    done(`crops=${q.crops.join(",")} ok=${q.ok}`);

    // 8) Phân tích quyết định đa tiêu chuẩn AHP & TOPSIS (Thuật toán 12)
    // Normalize slider preferences; these are not elicited pairwise AHP judgments.
    const ahpResult = deriveAHPWeightsFromPreferences([wSoil, wWater, wProfit]);
    const calibratedWeights = ahpResult.weights; // [wSoil, wWater, wProfit]

    const scenariosForTOPSIS = [
      { id: "baseline", label: "Mặc định (Lúa-Lúa-Nghỉ)", soil_hp: baseline.soil_hp, water_hp: baseline.water_hp, profit_hp: baseline.profit_hp },
      { id: "user", label: "Lựa chọn Nông dân", soil_hp: user.soil_hp, water_hp: user.water_hp, profit_hp: user.profit_hp },
      { id: "quantum", label: q.fallback_used ? "Tối ưu cổ điển (fallback)" : "QAOA mô phỏng thử nghiệm", soil_hp: quantum.soil_hp, water_hp: quantum.water_hp, profit_hp: quantum.profit_hp }
    ];
    const topsisRanked = rankScenariosTOPSIS(
      scenariosForTOPSIS,
      calibratedWeights,
      ["soil_hp", "water_hp", "profit_hp"],
      ["benefit", "benefit", "benefit"]
    );

    // 9) Đánh giá Quantum Match Score & Trạng thái Khả thi Nông học
    // Trong nông nghiệp chính xác: Điểm tương hợp phải phản ánh đồng thời độ tiệm cận nghiệm tối ưu
    // VÀ chất lượng nông học thực tế của vùng đất.
    // Nếu cả kịch bản của người dùng và AI Lượng tử đều rơi vào Rank C (hoặc overall < 35),
    // vùng đất là sa mạc khô hạn hoặc băng giá cực đoan, điểm không thể đánh giá là 98% "Xuất sắc" (Excellent)
    // mà phải chiết giảm theo mức độ khả thi thực tế (viability factor).
    let matchPct = 0;
    let matchDesc = "Run analysis to compare strategies";

    const isExtremeZone = (quantum.rank === "C" && user.rank === "C") || (quantum.overall < 35 && user.overall < 35);
    const isUserUnviable = user.rank === "C" || user.overall < 35;

    if (quantum.overall <= 0 && user.overall <= 0) {
      matchPct = 0;
      matchDesc = "🔴 High Risk — Environmental conditions do not support agriculture (Rank C)";
    } else if (isExtremeZone) {
      // Cả 2 kịch bản đều thất bại do đất đai cằn cỗi/sa mạc/băng giá
      const relativeCloseness = Math.max(0, 100 - Math.abs(user.overall - quantum.overall) * 2.5);
      const viabilityFactor = Math.min(1.0, Math.max(0.05, Math.max(user.overall, quantum.overall) / 60.0));
      matchPct = clamp(round(relativeCloseness * viabilityFactor, 1), 0, 100);
      matchDesc = "⚠️ Severe Environment — High failure risk for both rotations (Rank C)";
    } else if (isUserUnviable) {
      // Nông dân chọn cây trồng không phù hợp (Rank C), trong khi Lượng tử tìm ra giải pháp tốt hơn
      const diff = Math.max(0, quantum.overall - user.overall);
      matchPct = clamp(round(Math.max(5, 50 - diff * 0.8), 1), 0, 100);
      matchDesc = "🔴 High Risk — Selected crops are unviable in this climate (Rank C)";
    } else {
      // Vùng đất canh tác bình thường (Rank A, B, S):
      // Đánh giá khoảng cách tiệm cận giữa phương án người dùng và phương án lượng tử
      const diff = Math.abs(user.overall - quantum.overall);
      matchPct = clamp(round(100 - diff * 1.2, 1), 0, 100);
      matchDesc = matchPct >= 85 ? "🏆 Excellent — Very close to quantum optimal!"
        : matchPct >= 65 ? "👍 Good — Room for further optimization"
        : matchPct >= 45 ? "⚠️ Fair — Consider the quantum recommendation"
        : "🔴 Low — Quantum suggests a significantly better rotation";
    }

    const cropInfo = (keys) =>
      keys.map((k) => ({
        key: k, label: CROPS[k].label, color: CROPS[k].color,
        profit: CROPS[k].profit, water: CROPS[k].water, soil: CROPS[k].soil,
      }));

    const elevationMismatch=nasa._terrain.climate_representativeness==='limited_by_elevation_difference';
    const coldCoverageComplete=nasa._cold_risk.unknown_months.length===0;
    if(elevationMismatch){
      matchPct=null;
      matchDesc='Chênh lệch độ cao lớn: chỉ xem kết quả theo ô khí hậu NASA POWER; chưa đủ cơ sở khuyến nghị tại ruộng.';
    }

    res.json({
      ok: true,
      coords: { lat: round(lat, 4), lon: round(lon, 4) },
      source: nasa._source_description || 'NASA POWER climatology',
      source_status: nasa.source_status || 'climatology',
      recommendation_allowed: !elevationMismatch && coldCoverageComplete,
      recommendation_status: elevationMismatch ? 'elevation_mismatch' : coldCoverageComplete ? 'experimental' : 'cold_risk_incomplete',
      assessment_scope:'model_grid_climate',
      limitations: ['Scores, crop thresholds and climate proxies have no independent field validation.',
        'Climatology is not a forecast. No optical imagery or measured soil chemistry is loaded.'],
      provenance: nasa._provenance,
      variables: nasa._raw_catalog,
      derived_metadata: nasa._derived_meta,
      cold_risk: nasa._cold_risk,
      terrain: nasa._terrain,
      spi: {status:envAnomalies.spi_status,reason:envAnomalies.spi_reason || history.reason || null,
        source:history.source,period:history.period || null,details:envAnomalies.spi_details},
      satellite,
      alerts: alerts.slice(0, 10),
      monthly: {
        T2M_MIN_HISTORY: nasa._cold_risk.months.map(m=>m.daily?.minimum_tmin_c ?? null),
        T2M: nasa.T2M, T2M_MIN: nasa.T2M_MIN, TS: nasa.TS, RAIN: nasa.PRECTOTCORR,
        GWETROOT: nasa.GWETROOT, NDVI: nasa.NDVI,
        NDVI_SMOOTHED: nasa.NDVI_SMOOTHED || nasa.NDVI
      },
      scenarios: {
        baseline: { ...baseline, crop_info: cropInfo(baselineCrops) },
        user: { ...user, crop_info: cropInfo(userCrops) },
        quantum: {
          ...quantum,
          crop_info: cropInfo(q.crops),
          method: q.method,
          quantum_available: q.quantum_available,
          quantum_feasible: q.quantum_feasible,
          fallback_used: q.fallback_used,
          status: q.status,
          objective_version: q.objective_version || 'additive_rotation_v4',
          objective_score: q.objective_score,
          expected_energy: q.expected_energy ?? null,
          initial_expected_energy: q.initial_expected_energy ?? null,
          shots: q.shots,
          feasible_space_size: q.feasible_space_size ?? null,
          seed: q.seed ?? null,
          runtime_ms: q.runtime_ms,
          classical_runtime_ms: q.classical_runtime_ms,
          classical_best_score: q.classical_best_score,
          hardware_executed: false,
          probs: q.probs,
          classical_baseline: q.classical_baseline,
          optimality_gap_pct: q.optimality_gap_pct,
          feasibility_rate_pct: q.feasibility_rate_pct
        },
      },
      mcda: {
        weights: ahpResult,
        ahp: ahpResult, // legacy key; source is normalized sliders, not pairwise judgments
        limitations: "TOPSIS is relative to these candidates and uses heuristic/proxy scores.",
        topsis: topsisRanked
      },
      seasonal_clusters: seasonalRegimes.cluster_profiles,
      phenology: nasa._phenology ? {...nasa._phenology,status:'proxy',source:'Smoothed climate NDVI proxy',period:nasa._provenance?.period || null} : null,
      match_pct: matchPct,
      match_desc: q.fallback_used ? matchDesc.replace(/quantum/gi,'classical')
        : matchDesc.replace(/quantum optimal/gi,'the simulated QAOA candidate').replace(/quantum/gi,'simulated QAOA'),
      crops_meta: Object.fromEntries(Object.entries(CROPS).map(([k, v]) => [k, { label: v.label, color: v.color, suitability_model: SCIENTIFIC_CROP_PROFILES[k] }])),
    });
  } catch (e) {
    console.error("[/api/analyze] lỗi:", e);
    res.status(500).json({ ok: false, error: "Không thể hoàn tất phân tích." });
  }
});

// ─── GET /api/random_coords ──────────────────────────────────────────────────
router.get("/random_coords", (req, res) => {
  const zones = [
    [12.66, 108.03], // Đắk Lắk, Việt Nam (Tây Nguyên)
    [21.18, 105.23], // Phú Thọ, Việt Nam (Đồng bằng sông Hồng)
    [36.77, -119.41], // Fresno, California, Mỹ
    [41.58, -93.62],  // Iowa, Mỹ (Corn Belt)
    [-34.28, 142.06], // Mildura, Úc
    [28.61, 77.23],   // Delhi, Ấn Độ
    [39.9, 116.4],    // Bắc Kinh, Trung Quốc
    [-1.29, 36.82],   // Nairobi, Kenya
    [45.46, 9.19],    // Thung lũng Po, Ý
    [23.72, 90.41],   // Dhaka, Bangladesh
    [12.63, -8.00],   // Bamako, Mali
    [-15.78, -47.93], // Brasilia, Brazil
    [9.07, 7.39],     // Abuja, Nigeria
    [29.07, 31.09],   // Beni Suef, Ai Cập
    [48.20, 16.37],   // Vienna, Áo
  ];

  const [lat0, lon0] = zones[Math.floor(Math.random() * zones.length)];
  const lat = clamp(round(lat0 + uniform(-0.05, 0.05), 4), -60, 70);
  const lon = round(lon0 + uniform(-0.05, 0.05), 4);
  res.json({ lat, lon });
});

return router;
}
module.exports = createApiRouter();
module.exports.createApiRouter = createApiRouter;
