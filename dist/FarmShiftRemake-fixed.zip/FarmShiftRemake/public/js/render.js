function renderColdRisk(data) {
  const terrain=data.terrain,risk=data.cold_risk;
  const terrainEl=document.getElementById('terrain-summary');
  if(terrainEl){
    terrainEl.textContent=terrain?.site_elevation_m!==null && terrain?.site_elevation_m!==undefined
      ? `SRTM: ${Math.round(terrain.site_elevation_m)} m${terrain.high_elevation?' · Địa hình cao':''}`
      : 'Độ cao tại điểm: chưa có dữ liệu DEM.';
    if(terrain?.grid_elevation_m!==null && terrain?.grid_elevation_m!==undefined)terrainEl.textContent+=` · Ô NASA POWER: ${Math.round(terrain.grid_elevation_m)} m`;
    if(terrain?.climate_representativeness==='limited_by_elevation_difference')terrainEl.textContent+=' · Chênh độ cao lớn: nhiệt độ lưới có thể chưa đại diện tại ruộng.';
    terrainEl.title=JSON.stringify(terrain || {},null,2);
  }
  const summary=document.getElementById('cold-risk-summary');
  if(summary){
    summary.textContent=risk ? (risk.frost_months.length ? `Nguy cơ rét dưới 0°C: ${risk.frost_months.map(m=>'T'+m).join(', ')}.`
      : risk.status==='unavailable' ? 'Chưa đủ dữ liệu nhiệt độ tối thiểu để đánh giá rét.'
      : 'Không phát hiện dưới 0°C trong dữ liệu đã tải; chưa bảo đảm không có sương giá tại ruộng.') : 'Chưa đánh giá rét.';
    if(risk?.period)summary.textContent+=` Thời kỳ ${risk.daily_history?.status!=='unavailable'?'lịch sử ngày':'khí hậu'}: ${risk.period.start} – ${risk.period.end}.`;
    summary.textContent+=' Đây là dữ liệu lịch sử/khí hậu, không phải dự báo hoặc xác nhận cây đã chết.';
    summary.textContent+=' Mô hình sàng lọc cây ngoài trời không bảo vệ trong toàn bộ vụ 4 tháng; có thể cần đổi lịch gieo hoặc giống sau kiểm tra tại ruộng.';
  }
  const monthList=document.getElementById('cold-risk-months');
  if(monthList){
    monthList.innerHTML='';
    for(const m of risk?.months || []){
      const row=document.createElement('div');
      const minimum=m.daily?.minimum_tmin_c ?? m.climatology_tmin_c;
      row.className='cold-month '+(m.frost_risk==='detected'?'cold-detected':'');
      row.textContent=`T${m.month}: TB ${m.mean_temperature_c ?? 'N/A'}°C · ${m.daily?.minimum_tmin_c!==null && m.daily?.minimum_tmin_c!==undefined ? 'Tmin lịch sử' : 'Tmin khí hậu'} ${minimum ?? 'N/A'}°C`;
      if(m.daily?.freezing_days)row.textContent+=` · ${m.daily.freezing_days} ngày dưới 0°C · thấp nhất ${m.daily.coldest_date}`;
      else if(m.frost_risk==='unknown')row.textContent+=' · chưa đủ dữ liệu rét';
      if(m.daily?.status==='partial')row.textContent+=` · thiếu ${m.daily.missing_days}/${m.daily.expected_days} ngày`;
      monthList.appendChild(row);
    }
  }
  for(const [key,id] of [['user','user-season-risks'],['quantum','q-season-risks']]){
    const container=document.getElementById(id);if(!container)continue;container.innerHTML='';
    for(const season of data.scenarios?.[key]?.season_results || []){
      const row=document.createElement('div');row.className='season-risk';
      const riskMonths=season.cold_risk?.frost_months || [];
      row.textContent=`Vụ ${season.season} (${season.months.map(m=>'T'+m).join('–')}): `+
        (riskMonths.length && season.crop!=='Fallow' ? season.reason
          : season.is_lethal ? season.reason : season.crop==='Fallow' ? 'Nghỉ đất.'
          : season.cold_risk?.status==='unknown' ? 'Chưa đủ dữ liệu nhiệt độ thấp; cần kiểm tra rét tại ruộng.' : 'Không phát hiện rét trong dữ liệu đã tải; chưa phải bảo đảm an toàn.');
      container.appendChild(row);
    }
  }
}

// ─── Update UI ────────────────────────────────────────────────────────────────
function updateUI(data) {
  const sat = data.satellite;
  const sc  = data.scenarios;
  renderColdRisk(data);

  document.getElementById("data-source-badge").textContent = "Source: " + data.source;

  const sourceBadge = document.getElementById('data-source-badge');
  sourceBadge.textContent += ' · ' + data.source_status + ' · EXPERIMENTAL · SPI ' + data.spi.status;
  if(data.recommendation_allowed===false)sourceBadge.textContent+=' · Chỉ xem theo ô khí hậu; chưa đủ cơ sở khuyến nghị tại ruộng';
  sourceBadge.title = JSON.stringify({provenance:data.provenance,spi:data.spi.reason,limitations:data.limitations},null,2);
  const rows = document.querySelectorAll('.sat-row');
  ['POWER','SMAP','GPM','ECOSTRESS','MODIS'].forEach((key,i)=>{
    if (!rows[i]) return;
    const records = Object.values(sat[key].metadata).flat();
    const record = records[0];
    const period = record?.period ? JSON.stringify(record.period) : 'period unavailable';
    rows[i].querySelector('.sat-desc').textContent = sat[key].status + ' · ' + period;
    rows[i].title = sat[key].source + '\n' + JSON.stringify(sat[key].metadata,null,2);
  });

  const setVal = (id, v, suffix = "") => {
    const el = document.getElementById(id);
    if (el) el.textContent = (v !== null && v !== undefined) ? v + suffix : "N/A";
  };
  setVal("sv-temp",    sat.POWER.temp_avg, " °C");
  document.getElementById("sv-temp-rng").textContent =
    `TB tháng ${sat.POWER.temp_min}°C – ${sat.POWER.temp_max}°C · Rad ${sat.POWER.rad_avg} MJ/m²`;

  setVal("sv-gwet",    sat.SMAP.gwetroot_avg);
  document.getElementById("sv-gwet-sub").textContent =
    `Root zone · ${sat.SMAP.drought_months} drought month(s)`;

  setVal("sv-rain",    sat.GPM.rain_avg, " mm/mo");
  document.getElementById("sv-rain-sub").textContent =
    `Total ${sat.GPM.rain_total} mm/yr · ${sat.GPM.flood_months} flood risk month(s)`;

  setVal("sv-ts",      sat.ECOSTRESS.ts_max, " °C peak");
  document.getElementById("sv-esi").textContent =
    `ESI avg ${sat.ECOSTRESS.esi_avg} · ${sat.ECOSTRESS.heat_months} heat stress month(s)`;

  setVal("sv-ndvi",    sat.MODIS.ndvi_avg);
  document.getElementById("sv-ndvi-sub").textContent =
    `NDVI ${sat.MODIS.ndvi_min} – ${sat.MODIS.ndvi_max}`;

  // Alerts
  const alertsList = document.getElementById("alerts-list");
  alertsList.innerHTML = "";
  (data.alerts || []).forEach(a => {
    const level = (typeof a === "object" && a && a.level) ? a.level : "warning";
    const msg = (typeof a === "object" && a && a.msg) ? a.msg : String(a);
    const cls = level === "danger" ? "alert-danger"
              : level === "warning" ? "alert-warning" : "alert-ok";
    const box = document.createElement('div');
    box.className = 'alert-box ' + cls; box.textContent = msg; alertsList.appendChild(box);
  });
  document.getElementById("alerts-wrap").style.display = "block";

  // Charts
  buildCharts(data.monthly);

  // Match score
  document.getElementById("match-score").textContent = data.match_pct === null ? "N/A" : data.match_pct + "%";
  const descEl = document.getElementById("match-desc");
  const isExtreme = (sc.quantum && sc.quantum.rank === "C" && sc.user && sc.user.rank === "C") || (sc.quantum && sc.quantum.overall < 30);
  const matchDesc = data.match_desc || (
    isExtreme ? "⚠️ Severe Environment — High failure risk for both rotations (Rank C)"
    : (sc.user && sc.user.rank === "C") ? "🔴 High Risk — Selected crops are unviable in this climate (Rank C)"
    : data.match_pct >= 85 ? "🏆 Excellent — Very close to quantum optimal!"
    : data.match_pct >= 65 ? "👍 Good — Room for further optimization"
    : data.match_pct >= 45 ? "⚠️ Fair — Consider the quantum recommendation"
    : "🔴 Low — Quantum suggests a significantly better rotation"
  );
  descEl.textContent = matchDesc;
  if (matchDesc.startsWith("🏆")) descEl.style.color = "#34d399";
  else if (matchDesc.startsWith("👍")) descEl.style.color = "#38bdf8";
  else if (matchDesc.startsWith("⚠️")) descEl.style.color = "#fbbf24";
  else if (matchDesc.startsWith("🔴")) descEl.style.color = "#f87171";

  // User block
  document.getElementById("user-tags").innerHTML = cropTagsHTML(sc.user.crop_info);
  document.getElementById("user-rank").textContent = "RANK " + sc.user.rank;
  document.getElementById("user-rank").className = "rank-chip rank-" + sc.user.rank;
  document.getElementById("user-hp-soil").innerHTML   = hpBarHTML("🌱 Soil & Nitrogen HP",  sc.user.soil_hp);
  document.getElementById("user-hp-water").innerHTML  = hpBarHTML("💧 Water Budget HP",     sc.user.water_hp);
  document.getElementById("user-hp-profit").innerHTML = hpBarHTML("💰 Economic HP",         sc.user.profit_hp);

  // Quantum block
  document.getElementById("q-tags").innerHTML = cropTagsHTML(sc.quantum.crop_info);
  document.getElementById("q-rank").textContent = "RANK " + sc.quantum.rank;
  document.getElementById("q-rank").className = "rank-chip rank-" + sc.quantum.rank;
  document.getElementById("q-method").textContent = (sc.quantum.fallback_used ? "Classical fallback · " : "Experimental simulation · ") + sc.quantum.method;
  document.getElementById("q-hp-soil").innerHTML   = hpBarHTML("🌱 Soil & Nitrogen HP",  sc.quantum.soil_hp);
  document.getElementById("q-hp-water").innerHTML  = hpBarHTML("💧 Water Budget HP",     sc.quantum.water_hp);
  document.getElementById("q-hp-profit").innerHTML = hpBarHTML("💰 Economic HP",         sc.quantum.profit_hp);

  // Radar
  buildRadar(sc);

  // Auto-switch to arena tab
  setTimeout(() => {
    document.querySelectorAll(".tab-btn").forEach(b => b.classList.remove("active"));
    document.querySelectorAll(".tab-content").forEach(c => c.classList.remove("active"));
    document.getElementById("tab-arena").classList.add("active");
    document.querySelectorAll(".tab-btn")[1].classList.add("active");
  }, 400);
}

